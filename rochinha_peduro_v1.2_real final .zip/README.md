
# Rochinha Pé Duro Bot v1.2

Versão oficial com modos ativos:
- Ultra Conservador Ajustado
- Omega
- Zenith
- Moscou

Inclui lógica de stake, fair odds, e envio automatizado via Telegram.
